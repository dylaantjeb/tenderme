# Clarificatievragen

| Nr | Vraag                                      | Reden                                | Verwachte impact | Prioriteit |
|----|--------------------------------------------|--------------------------------------|------------------|------------|
| 1  | Wat zijn de exacte eisen voor digitale oplevering? | Onzekerheid over technische specificaties | Vertraging in oplevering | Hoog       |
| 2  | Zijn er specifieke eisen voor verkeersveiligheidsmaatregelen? | Onzekerheid over scope | Mogelijke herziening van plan | Middel    |

Benodigde input:
- Geen