# Risicoregister

| Nr | Risico                     | Kans  | Impact | Score | Maatregel                     | Eigenaar       | Status |
|----|----------------------------|-------|--------|-------|-------------------------------|----------------|--------|
| 1  | Weersomstandigheden        | Middel| Hoog   | 9     | Buffer in planning            | Jan Peters     | Open   |
| 2  | Vertraging vergunningen    | Laag  | Hoog   | 6     | Vroegtijdige aanvraag         | Sanne de Groot | Open   |
| 3  | Beschikbaarheid materieel  | Laag  | Middel | 4     | Onderhoudscontracten          | Lisa Vermeer   | Open   |

Benodigde input:
- Geen