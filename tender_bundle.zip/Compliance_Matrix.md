# Compliance Matrix

| Eis                  | Type (KO/REQ) | Voldoening | Toelichting/Bewijs               | Bijlage   |
|----------------------|---------------|------------|----------------------------------|-----------|
| ISO 9001             | KO            | Ja         | Certificaat geldig tot  | Bijlage A |
| ISO 14001            | KO            | Ja         | Certificaat geldig tot  | Bijlage B |
| 24/7 storingsdienst  | REQ           | Ja         | Dienstbeschrijving               | Bijlage C |
| Emissiearm materieel | REQ           | Ja         | Lijst materieel                  | Bijlage D |
| Digitale rapportages | REQ           | Ja         | Voorbeeldrapportage              | Bijlage E |

Benodigde input:
- Geldigheidsdata van certificaten