# Projectreferenties

| Opdrachtgever       | Project                     | Jaar    | Scope                                    | Resultaten/KPI’s                  | Referentiepersoon |
|---------------------|-----------------------------|---------|------------------------------------------|-----------------------------------|-------------------|
| Gemeente Amersfoort | Herinrichting stadswegen    | 2023–2024| Vervanging asfalt en rioolputten         | Tevredenheid: 8,4, Planning: 100%, Kwaliteit: 99% | Ja               |
| Provincie Utrecht   | Onderhoud N237              | 2022–2023| Asfaltvervanging en bermversteviging     | Tevredenheid: 8,1, Planning: 97%, Kwaliteit: 98% | Ja               |

Benodigde input:
- Geen