# Planning Gantt

| Fase                | Start | Eind  | Activiteiten                      | Gate-review |
|---------------------|-------|-------|-----------------------------------|-------------|
| Voorbereiding       | Jan 25| Mar 25| Inspectie, planning               | Feb 25      |
| Uitvoering          | Apr 25| Dec 28| Onderhoudswerkzaamheden           | Jun 25      |
| Nazorg & Oplevering | Jan 29| Dec 29| Evaluatie, rapportage             | Mar 29      |

```
| Fase                | Jan | Feb | Mar | Apr | May | Jun | Jul | Aug | Sep | Oct | Nov | Dec |
|---------------------|-----|-----|-----|-----|-----|-----|-----|-----|-----|-----|-----|-----|
| Voorbereiding       | ███ | ███ | ███ |     |     |     |     |     |     |     |     |     |
| Uitvoering          |     |     |     | ███ | ███ | ███ | ███ | ███ | ███ | ███ | ███ | ███ |
| Nazorg & Oplevering |     |     |     |     |     |     |     |     |     |     |     | ███ |
```

Benodigde input:
- Geen