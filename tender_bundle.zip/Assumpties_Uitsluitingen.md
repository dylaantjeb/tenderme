# Assumpties en Uitsluitingen

## Assumpties
| Aanname                   | Rationale                              | Impact bij afwijking               |
|---------------------------|----------------------------------------|------------------------------------|
| Prijsstelling vast        | Marktfluctuaties worden opgevangen     | Heronderhandeling contract         |
| Tijdige vergunningverlening| Noodzakelijk voor tijdige uitvoering   | Vertraging projectstart            |

## Uitsluitingen
| Uitsluiting               | Toelichting                            | Financiële consequentie            |
|---------------------------|----------------------------------------|------------------------------------|
| Onvoorziene bodemvervuiling | Buiten scope van huidige opdracht     | Extra kosten voor sanering         |

Benodigde input:
- Geen