# KPI & SLA Dashboard

| KPI/SLA         | Target | Meetmethode          | Frequentie | Escalatie | Verantwoordelijke |
|-----------------|--------|----------------------|------------|-----------|-------------------|
| Beschikbaarheid | ≥99%   | Systeemrapportages   | Maandelijks| Ja        | Jan Peters        |
| Responstijd     | ≤2 uur | Incidentregistratie  | Wekelijks  | Ja        | Sanne de Groot    |

Benodigde input:
- Geen