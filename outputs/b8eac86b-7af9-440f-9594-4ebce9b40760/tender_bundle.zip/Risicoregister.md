# Risicoregister

| Risico               | Kans    | Impact | Beheersmaatregel                          |
|----------------------|---------|--------|-------------------------------------------|
| Weersvertraging      | Middel  | Hoog   | Buffers + alternatieve werktijden         |
| Personeelstekort     | Laag    | Hoog   | Flexpool & vaste onderaannemers           |
| Materiaaltekort      | Laag    | Hoog   | Vaste leverancierscontracten              |
| Omgevingsklachten    | Laag    | Middel | Proactieve bewonerscommunicatie           |

Benodigde input: Geen
