# Assumpties en Uitsluitingen

- **Assumpties:**
  - Prijsstelling is vast en niet onderhandelbaar.
  - Geen afhankelijkheden van de opdrachtgever voor de uitvoering.
  - Garantieperiode van 12 maanden na oplevering.

- **Uitsluitingen:**
  - Eventuele wijzigingen in wet- en regelgeving na contractdatum.
  - Onvoorziene omstandigheden buiten onze controle, zoals natuurrampen.

Benodigde input: Geen
