# KPI/SLA Dashboard

| KPI/SLA                      | Target | Meetmethode             | Frequentie | Escalatie                    | Verantwoordelijke       | Link W-xx/criterium |
|------------------------------|--------|-------------------------|------------|------------------------------|-------------------------|---------------------|
| Klanttevredenheid            | ≥ 8,0  | Enquêtes opdrachtgever  | Halfjaarlijks | Escalatie naar directie     | Projectmanager          | W-01                |
| Responstijd storingen        | ≤ 2 uur| Incidentregistratie     | Continu    | Escalatie naar projectleider | Onderhoudscoördinator   | W-03                |
| Opleveringen binnen planning | ≥ 95%  | Projectrapportages      | Maandelijks| PMO-escalatie               | Projectmanager          | W-04                |
| CO₂-reductie t.o.v. referentie | ≥ 15% | Brandstof/CO₂-monitor   | Kwartaal   | Duurzaamheidsmanager        | Duurzaamheidsmanager    | W-02                |
| Ongevallen                   | 0      | VGM-rapportage          | Continu    | Veiligheidscoördinator      | Veiligheidscoördinator  | W-03                |

Benodigde input: Geen
