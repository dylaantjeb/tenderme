# Bewijsstukkenbundel

| Bijlage | Beschrijving                             | Relatie (W-xx / KO / REQ) | Status | Verwijzing |
|---------|------------------------------------------|---------------------------|--------|------------|
| A       | Kwaliteitsaanpak                         | W-01                      | Compleet| Sectie 8   |
| B       | Duurzaamheidsplan                        | W-02                      | Compleet| Sectie 8   |
| C       | Risicomanagementstrategie                | W-03                      | Compleet| Sectie 8   |
| D       | Prijsstelling                            | W-04                      | Compleet| Sectie 8   |
| E       | ISO 9001 Certificaat                     | KO                        | Compleet| Sectie UEA |
| F       | ISO 14001 Certificaat                    | KO                        | Compleet| Sectie UEA |
| G       | Procesbeschrijving GIS-portaal           | REQ                       | Compleet| Sectie GIBIT|

Benodigde input: Geen
