# Assumpties en Uitsluitingen

## Assumpties
| Aanname                      | Rationale                              | Impact bij afwijking          |
|------------------------------|----------------------------------------|-------------------------------|
| Tijdige vergunningverlening  | Noodzakelijk voor planning             | Vertraging in uitvoering      |
| Vrije toegang werkterreinen  | Essentieel voor continuïteit           | Stagnatie en extra kosten     |

## Uitsluitingen
| Uitsluiting                  | Toelichting                            | Financiële consequentie       |
|------------------------------|----------------------------------------|-------------------------------|
| Onvoorziene weersomstandigheden | Buiten onze controle                  | Mogelijke extra kosten        |

Benodigde input:
- Geen aanvullende input vereist.