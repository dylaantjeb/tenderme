# Risicoregister

| Nr | Risico                        | Kans  | Impact | Score | Maatregel                        | Eigenaar       | Status |
|----|-------------------------------|-------|--------|-------|----------------------------------|----------------|--------|
| 1  | Weersomstandigheden           | Middel| Hoog   | 9     | Buffer in planning               | Projectleider  | Open   |
| 2  | Vertraging vergunningen       | Laag  | Hoog   | 6     | Vroegtijdige aanvraag            | Contractmanager| Open   |
| 3  | Beschikbaarheid materieel     | Laag  | Middel | 3     | Onderhoudscontracten             | Logistiek      | Open   |
| 4  | Ongevallen op de werkplek     | Laag  | Hoog   | 6     | VCA**-gecertificeerde procedures | Veiligheidsmanager | Open   |

Benodigde input:
- Geen aanvullende input vereist.