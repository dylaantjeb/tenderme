# KPI/SLA Dashboard

| KPI/SLA                        | Target | Meetmethode                  | Frequentie | Escalatie | Verantwoordelijke |
|--------------------------------|--------|------------------------------|------------|-----------|-------------------|
| Klanttevredenheid              | ≥ 8,0  | Enquêtes                     | Halfjaarlijks| Management | Contractmanager   |
| Responstijd storingen          | ≤ 2 uur| Incidentregistratie          | Continu    | Technisch team | Projectleider    |
| Opleveringen binnen planning   | ≥ 95%  | Projectrapportages           | Maandelijks| Projectteam | Projectleider    |
| CO₂-reductie t.o.v. referentie | ≥ 15%  | CO₂-monitoring               | Jaarlijks  | Duurzaamheidsteam | Duurzaamheidsmanager |
| Ongevallen                     | 0      | Veiligheidsrapportages       | Continu    | Veiligheidsteam | Veiligheidsmanager |

Benodigde input:
- Geen aanvullende input vereist.