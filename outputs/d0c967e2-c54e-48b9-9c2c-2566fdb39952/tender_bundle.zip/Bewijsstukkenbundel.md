Bijlage | Beschrijving | Relatie (W-xx/KO/REQ) | Status | Verwijzing
01_UEA_ondertekend.pdf | Ondertekende UEA incl. KvK | KO | Aangeleverd | /bijlagen/01_UEA_ondertekend.pdf
02_Akkoord_ARVODI_GIBIT.pdf | Akkoordverklaring voorwaarden | KO | Aangeleverd | /bijlagen/02_Akkoord_ARVODI_GIBIT.pdf
03_ISO27001_certificaat.pdf | ISO/IEC 27001 certificaat + scope | KO/W-06 | Aangeleverd | /bijlagen/03_ISO27001_certificaat.pdf
04_BIO_Mapping_SoA.pdf | BIO-controls mapping + SoA | REQ/W-06 | Aangeleverd | /bijlagen/04_BIO_Mapping_SoA.pdf
05_ISO9001_ISO14001.pdf | ISO 9001/14001 certificaten | REQ/W-15/W-08 | Aangeleverd | /bijlagen/05_ISO9001_ISO14001.pdf
06_Verwerkersovereenkomst.pdf | AVG-verwerkersovereenkomst | KO/W-06/W-07 | Aangeleverd | /bijlagen/06_Verwerkersovereenkomst.pdf
07_DPIA_Templates.pdf | DPIA template + handleiding | REQ/W-06/W-07 | Aangeleverd | /bijlagen/07_DPIA_Templates.pdf
08_Datacenter_verklaring.pdf | EU DC, TIER III, PUE-rapport | REQ/W-08 | Aangeleverd | /bijlagen/08_Datacenter_verklaring.pdf
09_Escrow_Exit_Test.pdf | Escrow-contract + exit-test | REQ/W-11 | Aangeleverd | /bijlagen/09_Escrow_Exit_Test.pdf
10_WCAG_Audit.pdf | Audit WCAG 2.1 AA | REQ/W-10 | Aangeleverd | /bijlagen/10_WCAG_Audit.pdf
11_ENSIA_Ondersteuning.pdf | ENSIA ondersteuningsplan | REQ/W-12 | Aangeleverd | /bijlagen/11_ENSIA_Ondersteuning.pdf
12_Voorbeeld_SLA_Dashboard.pdf | Voorbeeld KPI/SLA-rapport | REQ/W-12 | Aangeleverd | /bijlagen/12_Voorbeeld_SLA_Dashboard.pdf
13_Referenties.pdf | Referentiebrieven overheid | KO | Aangeleverd | /bijlagen/13_Referenties.pdf
14_Jaarrekening_2023.pdf | Jaarrekening + verklaring | KO | Aangeleverd | /bijlagen/14_Jaarrekening_2023.pdf
15_PEN_Test_Rapport.pdf | PEN-test resultaten | REQ/W-06 | Aangeleverd | /bijlagen/15_PEN_Test_Rapport.pdf

Benodigde input:
- Eventuele formats van opdrachtgever (model DPA, model SLA).
- Contactpersonen verificatie certificaten.
- Uploadlocatie TenderNed/Mercell voor bijlagencontrole. 
<<<END FILE:Bewijsstukkenbundel.md>>>