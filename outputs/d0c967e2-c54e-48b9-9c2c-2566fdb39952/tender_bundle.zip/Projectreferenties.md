Referentie 1
- Opdrachtgever: Gemeente Noordstad
- Scope: SaaS-zaaksysteem, migratie 38 mln documenten, 24 integraties
- Doorlooptijd: 7 maanden; Go-live: 05/2024
- Resultaat: Uptime 99,92%, migratie-acc 99,97%, CSAT 8,4
- Contact: C. Bakker, CIO, +31 10 123 4567

Referentie 2
- Opdrachtgever: Provincie Rivierenland
- Scope: DMS/zaakarchief SaaS, BIO implementatie, ENSIA-ondersteuning
- Doorlooptijd: 6 maanden; Go-live: 11/2023
- Resultaat: 0 major ISO/BIO findings, WCAG conformiteit 99%, PUE 1,28
- Contact: L. van Dijk, Hoofd ICT, +31 26 987 6543

Referentie 3
- Opdrachtgever: Omgevingsdienst Delta
- Scope: Integraties Digikoppeling, eHerkenning, data-exit scenario getest
- Doorlooptijd: 5 maanden; Go-live: 03/2023
- Resultaat: Change lead time p90 = 4,2 werkdagen; Exit-test 100%
- Contact: S. Meijer, Teammanager ICT, +31 13 246 8100

Benodigde input:
- Eventuele referentieformaten/ sjablonen opdrachtgever.
- Toestemming voor delen contactgegevens bij verificatie.
- NDA of contactprotocol (indien vereist). 
<<<END FILE:Projectreferenties.md>>>