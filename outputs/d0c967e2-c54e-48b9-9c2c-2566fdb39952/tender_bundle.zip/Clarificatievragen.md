- Kunt u bevestigen welke integraties verplicht zijn in fase 1 (BRP, KCC, eHerkenning, Digikoppeling) en welke facultatief voor fase 2/3?
- Is er een voorkeursvenster voor gepland onderhoud (bijv. di/wo 22:00–02:00) en zijn er blackout dates?
- Welke kwaliteitsnorm voor datamigratie hanteert u als go/no-go drempel: 99,95% (W-04) of hoger/lager?
- Welke rapportageformaten accepteert u voor SLA/KPI (CSV, PowerBI push, PDF), en wie zijn de ontvangers?
- Zijn er bestaande WCAG-rapporten of styleguides die wij moeten volgen voor branding en toegankelijkheid?
- Welke gegevensverwerking vindt plaats met bijzondere persoonsgegevens en welke aanvullende maatregelen verwacht u?
- Wilt u performance credits/ malus opnemen en zo ja, welke bandbreedtes per KPI?
- Kunt u het exit-scenario specificeren (exportformaten, maximale doorlooptijd, parallel-run gewenst)?
- Is een OTAP-omgeving gewenst of volstaat DTAP en welke segmentatie-eisen gelden?
- Welke classificatie hanteert u voor incidentprioriteiten en escalatieroutes (P1–P4 definitie)?

Benodigde input:
- Beantwoording bovenstaande vragen vóór einde Nota van Inlichtingen.
- Technische contactpunten per ketenpartner.
- Beschikbaarheid van testdata en gewenste anonimisatiestandaard. 
<<<END FILE:Clarificatievragen.md>>>