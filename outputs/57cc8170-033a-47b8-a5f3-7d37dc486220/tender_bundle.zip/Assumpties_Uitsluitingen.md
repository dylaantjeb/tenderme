# Assumpties en Uitsluitingen

## Aannames
| Aanname | Rationale | Impact bij afwijking |
|---------|-----------|----------------------|
| Prijsstelling vast | Prijs is gebaseerd op huidige marktcondities | Heronderhandeling van contract |

## Uitsluitingen
| Uitsluiting | Toelichting | Financiële consequentie |
|-------------|-------------|-------------------------|
| Onvoorziene omstandigheden | Niet opgenomen in de planning | Extra kosten voor opdrachtgever |

Benodigde input:
- Geen