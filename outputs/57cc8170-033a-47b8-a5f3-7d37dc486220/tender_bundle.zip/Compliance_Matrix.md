# Compliance Matrix

| Eis | Type (KO/REQ) | Voldoening | Toelichting/Bewijs | Bijlage |
|-----|---------------|------------|--------------------|---------|
| ISO 9001 | KO | Ja | Certificaat geldig tot [TO FILL] | Bijlage A |
| ISO 14001 | KO | Ja | Certificaat geldig tot [TO FILL] | Bijlage B |
| 24/7 storingsdienst | KO | Ja | Contract met storingsdienst | Bijlage C |
| Oplevering binnen 8 maanden | KO | Ja | Projectplanning | Bijlage D |
| Emissiearm materieel | REQ | Ja | CO₂-prestatieladder niveau 4 | Bijlage E |

Benodigde input:
- Geldigheidsdata certificaten