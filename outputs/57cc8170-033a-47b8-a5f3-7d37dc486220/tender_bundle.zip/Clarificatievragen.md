# Clarificatievragen

| Nr | Vraag | Reden | Verwachte impact | Prioriteit |
|----|-------|-------|------------------|------------|
| 1 | Wat zijn de exacte locaties voor de drainagevoorzieningen? | Noodzakelijk voor gedetailleerde planning | Vertraging in planning | Hoog |
| 2 | Zijn er specifieke milieuvoorschriften die van toepassing zijn? | Beïnvloedt materiaalkeuze | Mogelijke herziening van materiaalkeuze | Middel |

Benodigde input:
- Antwoorden van de opdrachtgever