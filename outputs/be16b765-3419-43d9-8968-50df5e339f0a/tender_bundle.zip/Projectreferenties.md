Projectreferenties

Referentie 1 – Zaakgericht werken voor middelgrote gemeente (±120.000 inwoners)
- Omschrijving: Implementatie van SaaS Z/DMS met migratie van 4,2 TB, 6 integraties (BRP, BAG, KvK, eHerkenning, Outlook, SSO), OTAP en training van 850 gebruikers.
- Resultaat: Go-live in 15 weken; uptime 99,95% eerste 12 maanden; migratiefouten 0,006%; NPS +38 na 12 weken.
- Rollen: Technisch projectleider, migratielead, adoptiecoach, servicedesk.
- Contact: Op aanvraag via contractmanager.

Referentie 2 – Provinciale organisatie (±2.500 medewerkers)
- Omschrijving: SaaS DMS met zaakdossiers en integratie met M365 en identity-provider; design-to-operate overdracht met CAB en KPI-dashboard.
- Resultaat: 4 releases/jaar; standaardwijzigingen mediaan 6 werkdagen; 0 major security-incidenten.
- Rollen: Enterprise architect, change manager, service delivery manager.
- Contact: Op aanvraag via contractmanager.

Referentie 3 – Veiligheidsregio (multiketen)
- Omschrijving: Ketenintegratie met meldkamersystemen en zaakafhandeling; hoge beschikbaarheid en DR-oefeningen.
- Resultaat: 99,98% beschikbaarheid; DR-test RTO 2,5 uur; PUE 1,18; CO2 per gebruiker -27% in 18 maanden.
- Rollen: SRE lead, CISO liaison, testcoördinator.
- Contact: Op aanvraag via contractmanager.

Benodigde input:
- Toestemming en contactgegevens referenten voor deelbaarheid in het aanbestedingsdossier.