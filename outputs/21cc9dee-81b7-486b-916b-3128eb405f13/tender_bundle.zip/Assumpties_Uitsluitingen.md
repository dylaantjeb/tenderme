Assumpties en Uitsluitingen
- Data en toegang: Aanlevering van benodigde data en systemen conform afgesproken tijden.
- Integraties: Standaardisatie van interfaces; maatwerkdeployments buiten scope tenzij expliciet overeengekomen.
- Beperkingen van resources: Beschikbaarheid van sleutelpersoneel en leveranciers zonder onvoorziene onderbrekingen.
- Externe omstandigheden: externe economische factoren of afhankelijkheden buiten controle van de opdrachtnemer worden expliciet uitgesloten. Benodigde input:
