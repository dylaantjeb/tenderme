Strategische planning en mijlpunten
Fase 1: Voorbereiding en Clarificatie (Week 1-2) – afronding van requirements, risicoanalyse, en definities.
Fase 2: Uitwerking en Offerte (Week 3-6) – detaillering van design, W-criteria, KPI-structuur en bewijslast.
Fase 3: Beoordeling en Clarificatie (Week 7-8) – beantwoording van vragen, evaluatie en selectie.
Fase 4: Contractering en Implementatievoorbereiding (Week 9-12) – definitieve gunning, planningen, opleidingsplan.
Fase 5: realisatie en overdracht (Week 13+ ) – implementatie, acceptatie, en projectafsluiting.
Risico’s en mitigaties worden voortdurend gemonitord volgens PDCA-cyclus. Benodigde input:
