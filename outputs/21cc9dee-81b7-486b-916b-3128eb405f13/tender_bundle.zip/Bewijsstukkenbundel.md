Bewijslastbundel – mapping naar W-xx en KPI’s
- Voor W-01 (Waarde): business-case, ROI-analyses, benchmarking, referenties; KPI’s: TCO-reductie, doorlooptijd.
- Voor W-02 (Kwaliteit): kwaliteitsplannen, certificeringen (ISO), auditrapporten, wijzigingsbeheerlogs.
- Voor W-03 (Prijs/TCO): prijsoverzichten, kostenramingen, TCO-analyses, ramp-up-plannen.
- Voor W-04 (Implementatie): implementatieplan, service-level afspraken, training- en adoptieplannen.

Per bewijsstuk is duidelijk aangetoond waar het in de beoordelingsmethodiek en KPI-dashboard terugkomt. Benodigde input:
