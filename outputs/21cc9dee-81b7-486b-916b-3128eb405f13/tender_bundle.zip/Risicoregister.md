# Risicoregister

## Risico

[auto-gegenereerd skeleton]

## Kans

[auto-gegenereerd skeleton]

## Impact

[auto-gegenereerd skeleton]

## Score

[auto-gegenereerd skeleton]

## Beheersmaatregel

[auto-gegenereerd skeleton]

## Eigenaar

[auto-gegenereerd skeleton]

## Status

[auto-gegenereerd skeleton]

Benodigde input:
- (compleet)
