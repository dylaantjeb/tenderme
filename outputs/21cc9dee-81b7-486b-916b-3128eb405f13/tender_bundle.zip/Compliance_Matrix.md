KO-eisen en aannames
- KO-01 Kwalificatie: De opdrachtnemer voldoet aan de vereisten voor inschrijving en heeft aantoonbare ervaring met soortgelijke projecten. Ja
- KO-02 Technische capaciteit: De organisatie beschikt over de benodigde capaciteit, middelen en certificeringen om de uitvoering te waarborgen. Ja
- KO-03 Kwaliteitsmanagement: Er is een geïmplementeerd kwaliteitsmanagementsysteem en processen voor continue verbetering. Ja
- KO-04 Veiligheid en privacy: Voldoet aan relevante veiligheids- en privacy-eisen en heeft maatregelen voor incidentrespons. Ja

Benodigde input:


## UEA (Uniform Europees Aanbestedingsdocument)

| Eis | Type (KO/REQ) | Voldoening | Toelichting/Bewijs | Bijlage |
|-----|---------------|------------|---------------------|---------|
| Geen uitsluitingsgronden | KO | Ja | UEA Deel I–IV ingevuld en ondertekend | Bijlage UEA |


## GIBIT/ARVODI

| Voorwaarde | Type (KO/REQ) | Conform | Toelichting | Bijlage |
|------------|---------------|---------|-------------|---------|
| Acceptatie toepasselijke voorwaarden | REQ | Ja | Geen afwijkingen | Bijlage Voorwaarden |
