Clarificatievragen (voorbeeld)
- Kunnen er aanvullende normen of certificeringen worden vereist?
- Wat zijn de expliciete grenswaarden voor KPI-definities en hoe worden die gemeten?
- Zijn er aanvullende dataretentie- en privacy-eisen die wij moeten integreren?
- Wat zijn de acceptatiecriteria voor de oplevering en de go-live-momenten?
- Hoe wordt de governance-structuur binnen het project ingericht? Benodigde input:
