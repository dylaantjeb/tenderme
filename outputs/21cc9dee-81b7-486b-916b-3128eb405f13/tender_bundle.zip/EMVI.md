Test EMVI

W-01 Waarde voor de opdrachtgever: De oplossing levert aantoonbare meerwaarde voor de opdrachtgever door het verlagen van operationele kosten, verhogen van productie- of dienstverleningsefficiëntie en verbeteren van risico-management. De score wordt bepaald op basis van meetbare KPI's en hun relatie tot de doelstellingen van het programma.
W-02 Kwaliteit en naleving: De voorgestelde oplossing voldoet aan relevante normen, best practices en veiligheidsvereisten en toont een plan voor continue verbetering.
W-03 Prijs/TCO: De prijsstelling inclusief Total Cost of Ownership wordt vergeleken op basis van totale kosten gedurende de contractduur, inclusief onderhoud, migratie en training.
W-04 Implementatie en service: Implementatieplan, beschikbaarheid van service en response times, en governance/rapportage.

Benodigde input:


## Programma van Wensen (W-xx)

| Wensnr | Wens | Weging (punten/%) | Onze aanbieding | Bewijs (Bijlage) | Verwachte score |
|--------|------|-------------------|------------------|------------------|-----------------|
| W-01 | [sectorrelevante wens] | 20 | Concreet aanbod met meetbare waarde | Bijlage A | 18–20 |

