# Assumpties en Uitsluitingen

## Assumpties
| Aanname | Rationale | Impact bij afwijking |
|---------|-----------|----------------------|
| Prijzen zijn vast | Contractuele zekerheid | Heronderhandeling nodig |
| Toegang tot werkgebieden | Noodzakelijk voor planning | Vertragingen in planning |

## Uitsluitingen
| Uitsluiting | Toelichting | Financiële consequentie |
|-------------|-------------|-------------------------|
| Onvoorziene omstandigheden | Niet opgenomen in de planning | Extra kosten mogelijk |

Benodigde input:
- Geen
