# Planning Gantt

| Fase | Start | Eind | Activiteiten | Gate-review |
|------|-------|------|--------------|-------------|
| Kick-off | 2025-11-01 | 2025-11-02 | Projectbijeenkomst | 2025-11-02 |
| Inspecties & werkvoorbereiding | 2025-11-03 | 2025-12-20 | Inspecties, voorbereiding | 2025-12-20 |
| Uitvoering fase 1 | 2026-01-05 | 2026-03-31 | Uitvoeren werkzaamheden | 2026-03-31 |
| Uitvoering fase 2 | 2026-04-01 | 2026-06-30 | Uitvoeren werkzaamheden | 2026-06-30 |
| Nazorg & Oplevering | 2026-07-01 | 2026-07-15 | Oplevering en evaluatie | 2026-07-15 |

```
| Fase                | Nov | Dec | Jan | Feb | Mar | Apr | May | Jun | Jul |
|---------------------|-----|-----|-----|-----|-----|-----|-----|-----|-----|
| Kick-off            | ███ |     |     |     |     |     |     |     |     |
| Inspecties & Voorb. | ███ | ███ |     |     |     |     |     |     |     |
| Uitvoering fase 1   |     |     | ███ | ███ | ███ |     |     |     |     |
| Uitvoering fase 2   |     |     |     |     |     | ███ | ███ | ███ |     |
| Nazorg & Oplevering |     |     |     |     |     |     |     |     | ███ |
```

Benodigde input:
- Geen
