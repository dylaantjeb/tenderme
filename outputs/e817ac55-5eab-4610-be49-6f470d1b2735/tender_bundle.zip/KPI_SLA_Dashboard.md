# KPI/SLA Dashboard

| KPI/SLA | Target | Meetmethode | Frequentie | Escalatie | Verantwoordelijke |
|---------|--------|-------------|------------|-----------|-------------------|
| Beschikbaarheid | ≥99% | Monitoring software | Maandelijks | Projectmanager | Sanne de Groot |
| Responstijd | ≤2 uur | Incident tracking | Wekelijks | Technisch manager | Sanne de Groot |

Benodigde input:
- Aanvullende KPI's/SLA's