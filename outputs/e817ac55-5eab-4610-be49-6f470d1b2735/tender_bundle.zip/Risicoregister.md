# Risicoregister

| Nr | Risico | Kans | Impact | Score | Maatregel | Eigenaar | Status |
|----|--------|------|--------|-------|-----------|----------|--------|
| 1 | Weersomstandigheden | Middel | Hoog | 9 | Buffer in planning | Projectleider | Open |
| 2 | Leveringsvertraging | Laag | Middel | 6 | Alternatieve leveranciers | Inkoopmanager | Open |

Benodigde input:
- Aanvullende risico's en maatregelen