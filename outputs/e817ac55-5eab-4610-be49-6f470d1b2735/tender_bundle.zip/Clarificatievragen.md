# Clarificatievragen

| Nr | Vraag | Reden | Verwachte impact | Prioriteit |
|----|-------|-------|------------------|------------|
| 1 | Wat zijn de exacte startdata voor elke fase? | Planning | Vertraging in uitvoering | Hoog |
| 2 | Zijn er specifieke milieunormen waaraan voldaan moet worden? | Compliance | Aanpassing ontwerp | Middel |

Benodigde input:
- Antwoorden op clarificatievragen