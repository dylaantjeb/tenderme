# Planning Gantt

| Fase | Start | Eind | Activiteiten | Gate-review |
|------|-------|------|--------------|-------------|
| Voorbereiding | [TO FILL] | [TO FILL] | Site survey, ontwerp | [TO FILL] |
| Uitvoering | [TO FILL] | [TO FILL] | Aanleg drainage | [TO FILL] |
| Nazorg & Oplevering | [TO FILL] | 2025-12-01 | Monitoring, onderhoud | [TO FILL] |

```
| Fase                | Jan | Feb | Mar | Apr | May |
|---------------------|-----|-----|-----|-----|-----|
| Voorbereiding       | ███ | ███ |     |     |     |
| Uitvoering          |     | ███ | ███ | ███ |     |
| Nazorg & Oplevering |     |     |     | ███ | ███ |
```

Benodigde input:
- Start- en einddata van de fasen