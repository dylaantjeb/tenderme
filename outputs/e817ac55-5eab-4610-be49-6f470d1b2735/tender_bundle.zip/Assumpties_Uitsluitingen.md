# Assumpties en Uitsluitingen

## Assumpties
| Aanname | Rationale | Impact bij afwijking |
|---------|-----------|----------------------|
| Prijsstelling blijft vast | Marktfluctuaties zijn minimaal | Heronderhandeling van contract |

## Uitsluitingen
| Uitsluiting | Toelichting | Financiële consequentie |
|-------------|-------------|-------------------------|
| Onvoorziene grondcondities | Niet opgenomen in scope | Extra kosten voor opdrachtgever |

Benodigde input:
- Aanvullende aannames en uitsluitingen