Projectreferenties InfraTech Solutions B.V.

1) Gemeente Utrecht — Wijkonderhoud Noordwest (2021–2024)
- Omvang: € 9,1 mln; onderhoud asfalt- en elementenverhardingen, data-oplevering GIS.
- Resultaten: 96% binnen planning; CO₂ −31%; klanttevredenheid 8,3.
- Contact: Gemeente Utrecht, dhr. P. van Aalst (contractmanager), p.vanaalst@utrecht.nl, 030-286 0000.

2) Gemeente Amersfoort — Raamcontract Wegenonderhoud (2020–2023)
- Omvang: € 7,4 mln; LEAB-deklagen, voegvulling, markering, winterdienst.
- Resultaten: Responstijd storingen gem. 58 min; 100% tijdige rapportages; RAP 55%.
- Contact: Gemeente Amersfoort, mevr. L. Hermans, l.hermans@amersfoort.nl, 033-469 0000.

3) Provincie Utrecht — Groot onderhoud N234 (2023)
- Omvang: € 4,8 mln; deklaagvervanging, bermverbetering, fietsveiligheidsmaatregelen.
- Resultaten: IRI 1,7 m/km; SRT 58; CO₂ −28%.
- Contact: Provincie Utrecht, ir. T. de Ruiter, t.deruiter@provincie-utrecht.nl, 030-258 9111.

Benodigde input:
- Toestemming contactpersonen voor referentiecheck door opdrachtgever.>>>