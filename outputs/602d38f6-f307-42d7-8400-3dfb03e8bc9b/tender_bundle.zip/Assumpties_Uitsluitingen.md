Assumpties
- Werkvensters: nacht- en daluren zijn toegestaan buiten evenementen en examendagen scholen.
- Toegang GIS: gemeente levert API-token en IMBOR-profiel.
- Emissiearm materieel: HVO100 wordt geaccepteerd als emissiearm alternatief voor Euro VI diesel.
- Winterdienst: pre-alert wordt verstrekt via gemeentelijk meldsysteem met minimaal 45 min vooraankondiging.
- Indexering: prijsaanpassing conform RAW-indexeringsregeling per 1 januari van elk jaar.

Uitsluitingen
- Verleggen/aanpassen kabels en leidingen buiten noodherstel.
- Archeologisch onderzoek buiten de verhardingsconstructie.
- Vergunningen buiten verkeersmaatregelen conform CROW 96a/97b.
- Nachtwerktoeslagen buiten overeengekomen werkvensters.

Benodigde input:
- Gemeentelijke uitzonderingskalender (evenementen, examendata).
- Bevestiging indexeringsregeling en boetebepalingen bij SLA-overschrijding.>>>