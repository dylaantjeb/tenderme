Clarificatievragen aan de aanbestedende dienst

1. Beoordelingsmethodiek
- Kunt u bevestigen dat de weging is: Kwaliteit 40%, Duurzaamheid 20%, Risicobeheersing 20%, Prijs 20% en dat afronding op 0,1 punt plaatsvindt?

2. GIS-rapportage
- Welke datastandaard en versie voor IMBOR verwacht u (versienummer en verplichte velden)?
- Is er een test-omgeving of sandbox-API beschikbaar inclusief voorbeeldtoken?

3. Emissie-eisen
- Wordt HVO100 als emissiearm volwaardig geaccepteerd voor zwaar materieel en zijn specifieke leveranciers voorgeschreven?

4. Verkeersmaatregelen
- Mag in alle woonstraten nachtwerk plaatsvinden of gelden geluidsplafonds met afwijkende venstertijden?

5. Winterdienst
- Welke prioritering geldt voor fietsroutes versus autowegen bij gelijktijdige gladheidsbestrijding?

6. Social return
- Kunt u de definitie van de loonsom en de meetwijze van de 5% SR bevestigen (in-/uitbesteed werk)?

Benodigde input:
- Reactie op bovenstaande vragen uiterlijk 10 werkdagen voor inschrijfdatum.>>>