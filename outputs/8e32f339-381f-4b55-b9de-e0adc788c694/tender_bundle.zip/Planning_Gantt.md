Tijdlijn (weken 1-24)
Legende: █ taak actief, ░ buffer/test

Week:  1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24
Init & Discovery        █ █ █
Architectuur & Ontwerp        █ █ █
Realisatie & Configuratie              █ █ █ █ █ █
Integraties & Data Prep                 █ █ █ █
Training Key-Users                           █ █ █
SIT/UAT/Performance                               █ █ █ █
Security: Pentest & Fix                               █ █ █
Go/No-Go                                                █
Cut-over & Go-Live                                        █
Hypercare                                                  █ █
Exploitatie & SLA                                                █ █ █ █ █ █
Kwartaal-innovatie                                                  ░     ░
Kwartaal-failover test                                                    ░     ░

Afhankelijkheden
- Architectuur & Ontwerp start na Initiatie.
- Integraties & Data Prep parallel aan Realisatie.
- SIT/UAT volgt na Realisatie; Pentest overlapt eind SIT.
- Go/No-Go na pentest-fixes; Cut-over in afgesproken venster.
- Hypercare 2 weken; daarna reguliere exploitatie en KPI-sturing.

Benodigde input:
- Gewenste go-live datum en onderhoudsvenster.
- Blackout dates en change freeze periodes.
- Beschikbaarheid key-users en testers. 
>>>