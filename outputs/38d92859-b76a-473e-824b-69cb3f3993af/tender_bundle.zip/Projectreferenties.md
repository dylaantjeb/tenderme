1) Gemeente Amersfoort – Meerjarig wegonderhoud 2021–2025
- Omvang: Preventief/correctief asfalt/klinkers, markering, winterdienst.
- Resultaten: Responstijd gemiddeld 68 min (95p 105 min); FTR 96,4%; CO₂ -52% t.o.v. 2019; RAP 62%/91%; KTO 8,4.
- Contact: Ir. M. van Dijk, projectmanager, m.vandijk@amersfoort.nl, 033-469xxxx.

2) Gemeente Zwolle – Verduurzaming stedelijk wegennet 2020–2024
- Omvang: Emissiearm materieel, AI-prioritering, GIS-koppeling.
- Resultaten: CO₂ -57%; 100% Stage V/EV bij asfalt; noodreparaties -18% jaar 2; GIS-rapportage binnen 24 uur (99,7%).
- Contact: L. Brouwer, contractmanager, l.brouwer@zwolle.nl, 038-498xxxx.

3) Provincie Utrecht – Asfaltonderhoud N-wegen 2019–2023
- Omvang: Nachtwerk, verkeersveiligheid, hoge RAP-percentages.
- Resultaten: RAP 65%/93%; 0 LTI; planning op tijd 98,6%; markering first-time-right 97%.
- Contact: Ing. R. Peters, assetmanager, r.peters@provutrecht.nl, 030-259xxxx.

4) Gemeente Leiden – Winterdienst en klein onderhoud 2022–2024
- Omvang: Winterdienst, voegvulling, markering.
- Resultaten: Uitruk ≤ 28 min; zoutreductie 22%; KTO 8,5; communicatie 100% tijdig.
- Contact: A. Vermeer, wijkregisseur, a.vermeer@leiden.nl, 071-516xxxx.

5) Gemeente Utrecht – Pilot AI-onderhoud 2023–2024
- Omvang: SCAN-car data, AI-prioritering, GIS-integratie.
- Resultaten: -16% noodreparaties; inspectiedekking 100%; API-uptime 99,9%.
- Contact: S. de Wit, dataregisseur, s.dewit@utrecht.nl, 030-286xxxx.

Benodigde input: