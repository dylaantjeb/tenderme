Bijlage | Beschrijving | Relatie (W-xx/KO/REQ) | Status | Verwijzing (pag./sectie)
A1 | ISO 9001 certificaat InfraTech Solutions | KO | Definitief | Certificaat §1
A2 | ISO 14001 certificaat InfraTech Solutions | KO | Definitief | Certificaat §1
A3 | VCA** certificaat | REQ | Definitief | Certificaat §1
A4 | CO₂-prestatieladder niveau 4 certificaat | REQ | Definitief | Certificaat §1
A5 | Kwaliteitsplan RAW/IMBOR + Keuringsplan | W-08; W-12; REQ | Definitief | Plan §2–§5
A6 | Milieumanagementplan & Circulariteit | W-07; REQ | Definitief | Plan §3
A7 | CO₂-reductieplan 2025–2029 | W-04; REQ | Definitief | Plan §4
A8 | Materieeloverzicht + Stage V/EV verklaringen | W-05; REQ | Definitief | Lijst §2
A9 | GIS-koppelingsplan + API-specificatie + DPIA-light | W-03; REQ | Definitief | TechSpec §3
A10 | Winterdienstplan (routes, SLA, zoutreductie) | W-01; W-11; REQ | Definitief | Plan §2
A11 | Verkeersveiligheidsplan (VVP) + VTMS | W-06; W-12; REQ | Definitief | Plan §2
A12 | Omgevingscommunicatieplan | W-10; REQ | Definitief | Plan §2
A13 | V&G/Veiligheidsplan + LMRA/TRA formats | W-06; W-13 | Definitief | Plan §2
A14 | Referentiebrieven en prestatieverklaringen | EMVI | Definitief | Zie Projectreferenties
A15 | Detailplanning (MS Project export) | W-12 | Definitief | Planning §1
A16 | Inspectieprotocol (SCAN-car/IMBOR) + AI-nota | W-02; W-14 | Definitief | Protocol §2
A17 | Data Security & Privacy Statement (logging/autorisatie) | REQ | Definitief | Statement §2

Benodigde input: