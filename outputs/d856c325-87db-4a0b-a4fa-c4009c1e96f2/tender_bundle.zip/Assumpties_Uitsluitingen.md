Assumpties
- Opdrachtgever levert tijdig toegang tot systemen, overdrachtsdossiers en contactpersonen.
- Servicewindow-tijden zijn standaard kantoortijden met optionele piekverlengingen volgens prijsblad.
- Dataclassificatie en privacy-impact worden bij start bevestigd; DPIA wordt uitgevoerd bij significante wijzigingen.
- Wijzigingen in scope worden via CAB en change-procedures ingevoerd met effect op planning/prijs.
- Maandrapportage wordt geaccepteerd als primair stuurdocument; kwartaalreviews voor strategische beslissingen.

Uitsluitingen
- Hardwarevervanging en -aanschaf vallen buiten scope tenzij expliciet opgenomen in prijsblad.
- Derde-partij licentiekosten en cloudkosten zijn voor rekening opdrachtgever, tenzij anders overeengekomen.
- Onvoorziene beveiligingsincidenten door toeleveranciers buiten onze macht vallen buiten aansprakelijkheid, behoudens nalatigheid.
- Werkzaamheden buiten overeengekomen servicewindow worden als meerwerk uitgevoerd.

Benodigde input:
- Definitieve scope en out-of-scope componenten.
- Bevestiging servicewindow en escalatiepaden.>>>