ASCII Gantt (week 0–24)

Fase/Activiteit                |0|1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24
Projectinitiatie (go/no-go)    |==|
Kick-off & Intake              |==|
Mobilisatie kernteam           |==|
Overdracht & Onboarding        |== ==|
Servicewindow live             |   == == == == == == == == == == == == == == == == == == == == == ==|
Stabilisatie & Quick wins      |     ==== ==== ====|
Procesfine-tuning (ITIL)       |       ==== ==== ==== ====|
RISMAN-sessies (maandelijks)   |     ==  ==  ==  ==  ==  ==  ==  ==  ==  ==  ==  ==  ==  ==  ==  ==|
Maandrapportages (dag 5)       |        *     *     *     *     *     *     *     *     *     *     *
Kwartaal-audits (QMS/ISMS)     |                A                 A                 A
Innovatieboard (per kwartaal)  |                I                 I                 I
Training & Kennisoverdracht    |       == == == == == == == == == == == == == == == == == == == ==|
CO2/SROI Kwartaalreviews       |                C                 C                 C
Klanttevredenheid (NPS)        |                N                 N                 N
Klantoverleggen (wekelijks)    |     : : : : : : : : : : : : : : : : : : : : : : : :
Evaluatie & Verbeterplan       |                      ====                ====                ====

Legenda:
- == taakduur
- * maandrapportage (KPI-05)
- A auditmoment (KPI-13)
- I innovatieboard (KPI-12)
- C CO2/SROI review (KPI-07/KPI-08)
- N NPS-meting (KPI-11)
- : wekelijks overleg

Benodigde input:
- Gewenste livegangdatum en servicewindow (dagen/uren).
- Beschikbaarheid opdrachtgever voor kick-off, audits en innovatieboards.>>>