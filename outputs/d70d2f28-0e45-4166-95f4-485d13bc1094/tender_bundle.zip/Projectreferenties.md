# Projectreferenties

InfraTech Solutions B.V. heeft diverse projecten succesvol afgerond die relevant zijn voor deze aanbesteding. Hieronder een selectie:

1. **Project A**: Onderhoud en verduurzaming van provinciale wegen in Noord-Holland. Inclusief CO₂-reductie en gebruik van emissiearm materieel.
2. **Project B**: Stedelijk onderhoudsproject in Rotterdam met focus op digitale oplevering en bewonerscommunicatie.

Benodigde input: Geen
