# KPI/SLA Dashboard

| KPI/SLA                      | Target  | Meetmethode             | Frequentie  | Escalatie                     | Verantwoordelijke          | Link W-xx/criterium |
|------------------------------|---------|-------------------------|------------|-------------------------------|----------------------------|---------------------|
| Klanttevredenheid            | ≥ 8,0   | Enquêtes opdrachtgever  | Halfjaarlijks | Escalatie naar directie       | Projectmanager             | W-01                |
| Responstijd storingen        | ≤ 2 uur | Incidentregistratie     | Continu    | Escalatie naar projectleider  | Storingsdienstcoördinator  | W-02                |
| Opleveringen binnen planning | ≥ 95%   | Projectrapportages      | Maandelijks | PMO-escalatie                 | Projectmanager             | W-03                |
| CO₂-reductie t.o.v. referentie | ≥ 15% | Brandstof/CO₂-monitor   | Kwartaal   | Escalatie naar duurzaamheidsmanager | Duurzaamheidsmanager | W-01                |
| Ongevallen                   | 0       | VGM-rapportage          | Continu    | Veiligheidscoördinator        | Veiligheidscoördinator     | -                   |

Benodigde input: Geen
