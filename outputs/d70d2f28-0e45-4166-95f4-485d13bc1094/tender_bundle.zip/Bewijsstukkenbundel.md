# Bewijsstukkenbundel

| Bijlage | Beschrijving                               | Relatie (W-xx / KO / REQ) | Status | Verwijzing          |
|---------|--------------------------------------------|---------------------------|--------|---------------------|
| A       | CO₂-reductieplan                           | W-01                      | Compleet | Sectie 8, EMVI.md   |
| B       | Storingsdienst protocol                    | W-02                      | Compleet | Sectie 8, EMVI.md   |
| C       | GIS-integratie documentatie                | W-03                      | Compleet | Sectie 8, EMVI.md   |
| D       | ISO 9001 certificaat                       | KO                        | Compleet | Compliance Matrix   |
| E       | ISO 14001 certificaat                      | KO                        | Compleet | Compliance Matrix   |
| F       | Voorbeeld digitale weekrapportage          | REQ                       | Compleet | Compliance Matrix   |
| G       | Lijst van emissiearm materieel             | REQ                       | Compleet | Compliance Matrix   |

Benodigde input: Geen
