# Risicoregister

| Risico              | Kans     | Impact  | Mitigatie                                    |
|---------------------|----------|---------|----------------------------------------------|
| Weersvertraging     | Middel   | Hoog    | Buffers inplannen en alternatieve werktijden |
| Personeelstekort    | Laag     | Hoog    | Flexpool en vaste onderaannemers             |
| Materiaaltekort     | Laag     | Hoog    | Vaste leverancierscontracten                 |
| Omgevingsklachten   | Laag     | Middel  | Proactieve bewonerscommunicatie              |

Benodigde input: Geen
