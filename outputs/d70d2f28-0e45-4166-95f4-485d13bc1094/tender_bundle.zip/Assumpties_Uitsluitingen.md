# Assumpties en Uitsluitingen

## Assumpties
- Prijsstelling is vast en niet onderhandelbaar.
- Er zijn geen afhankelijkheden van de opdrachtgever die de uitvoering kunnen vertragen.

## Uitsluitingen
- Eventuele vertragingen door extreme weersomstandigheden vallen buiten onze verantwoordelijkheid.

Benodigde input: Geen
