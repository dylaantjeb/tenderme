# Clarificatievragen

1. Kan de opdrachtgever verduidelijken of er specifieke eisen zijn voor de digitale oplevering via het GIS-portaal?
2. Zijn er specifieke richtlijnen voor de communicatie met bewoners tijdens de uitvoeringsfase?

Benodigde input: Geen
