# Planning Gantt

| Fase                        | Startdatum | Einddatum  |
|-----------------------------|------------|------------|
| Kick-off                    | 2025-11-01 | 2025-11-02 |
| Inspecties & werkvoorbereiding | 2025-11-03 | 2025-12-20 |
| Uitvoering fase 1           | 2026-01-05 | 2026-03-31 |
| Uitvoering fase 2           | 2026-04-01 | 2026-06-30 |
| Nazorg & Oplevering         | 2026-07-01 | 2026-07-15 |

Benodigde input: Geen
