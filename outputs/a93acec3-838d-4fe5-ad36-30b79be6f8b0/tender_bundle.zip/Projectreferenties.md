Referentie 1
- Opdrachtgever: Regionaal Publiek Bedrijf
- Omschrijving: Fasegewijze implementatie van CMMS met 24/7 continuïteitsborging.
- Omvang: 12 locaties, 2.500 assets, 10 maanden.
- Resultaat: 99,85% beschikbaarheid; 28% minder storingskilometers; FTR 97%.
- Rol: Hoofdaannemer; verantwoordelijk voor PvA, CMMS, KPI/SLA, training.

Referentie 2
- Opdrachtgever: Gemeentelijke Dienst
- Omschrijving: Renovatie en digitalisering technische installaties met BIM-coördinatie.
- Omvang: 5 panden, 8 maanden.
- Resultaat: Oplevering op planning; CO2 -22%; UAT 96% in 1 ronde.
- Rol: Integraal projectmanagement, kwaliteits- en risicoborging.

Referentie 3
- Opdrachtgever: Rijksinstantie
- Omschrijving: Contractmanagement en prestatiesturing onder ARVODI.
- Omvang: Meerjarig beheercontract, 36 maanden.
- Resultaat: KPI-score 99% tijdige rapportages; 0 kritieke beveiligingsincidenten.
- Rol: Contractmanager, PMO en PDCA-verbetering.

Benodigde input:
- Specifieke referentie-eisen (minimaal/vergelijkbaarheid).
- Contactpersonen referenten en toestemming benadering.
- Eventuele referentieformulieren van aanbestedende dienst.>>>