Clarificatievragen
1) Kunt u bevestigen welke prestatie-indicatoren leidend zijn bij gunning indien deze afwijken van ons KPI-voorstel (bijv. caps op bonus/malus)?
2) Welke productietijden en onderhoudsvensters gelden per locatie/systeem en gelden er change freezes (feestdagen/pieken)?
3) Wat is de gewenste diepgang en het format voor het overdrachtsdossier (DNO), en welke acceptatiecriteria (UAT/SAT) zijn knock-out?
4) Bevestigt u dat ARVODI/GIBIT zonder aanvullende afwijkingen van toepassing is? Indien afwijkingen gelden, graag een lijst met wijzigingen.
5) Zijn er eisen voor databerging/dataretentie (land, duur) en specifieke encryptiestandaarden die verplicht zijn?
6) Gelieve beschikbare referentieformats te verstrekken en aan te geven of referentiecontacten vooraf benaderd mogen worden.
7) Zijn er verplichte formats voor planning (MSP/Primavera) of worden onze ASCII/Excel-exports geaccepteerd?
8) Verlangt u een specifieke weergave van CO2-rapportages (CO2-PL niveau, indicatoren) en auditmomenten?
9) Wilt u de prioritering P1/P2/P3 en responstijden bevestigen voor incident- en escalatieafhandeling?

Benodigde input:
- Nota van inlichtingen deadlines en indieningswijze.
- Eventuele formats/templates voor dossiers en rapportages.
- Informatie over contactpersonen voor operationele afstemming.>>>