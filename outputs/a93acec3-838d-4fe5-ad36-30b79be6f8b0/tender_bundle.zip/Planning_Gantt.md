ASCII Gantt (W = week)
Fase/Activiteit                | W1 W2 W3 W4 W5 W6 W7 W8 W9 W10 W11 W12
Initiatie & Kick-off           | ████
Nulmeting & Risicoworkshop     |   ███
Detailplanning & PvA           |     ████
DPIA & VGM-plan                |       ███
Engineering/Voorbereiding      |         ██████
Inkoop & Logistiek             |           █████
CMMS Configuratie & Pilot      |             ████
Realisatie Werkstroom A        |                 ███████
Realisatie Werkstroom B        |                   ███████
QA/Audits & Inspecties         |                 █ █ █ █ █ █
UAT/SAT                        |                          ███
Oplevering & Overdracht        |                             ███
Hypercare                      |                                ███
Projectafsluiting & Evaluatie  |                                   ██

Afhankelijkheden
- Nulmeting → Detailplanning → Engineering → Realisatie → UAT/SAT → Oplevering.
- DPIA/VGM gereed vóór start realisatie.
- CMMS pilot vóór volledige uitrol.

Benodigde input:
- Beschikbaarheid sleutelstakeholders voor workshops en UAT/SAT.
- Venstertijden/werkstopperiodes van de opdrachtgever.
- Specifieke mijlpalen en harde einddata (indien contractueel vastgelegd).>>>