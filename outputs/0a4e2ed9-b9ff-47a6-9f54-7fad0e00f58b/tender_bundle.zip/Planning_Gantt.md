Legenda: █ werkperiode | △ mijlpaal/gate

2025
- Inschrijffase (10-01 → 12-01)     █████████████████████
- Vragenronde/NvI (10-15 → 11-15)    ███████████
- Gunning & contractering (12-15 → 12-31)  █████
  △ G1: Voorlopige gunning (12-15)
  △ G2: Contract getekend (12-30)

2026
- Mobilisatie & nulmeting (01-05 → 02-15)  █████████
  △ G3: Datakoppeling GIS live (02-01)
  △ G4: Nulmetingsrapport (02-15)
- Preventief onderhoud cyclus 1 (03-01 → 10-31) ███████████████████████
- Winterdienst seizoen 26/27 (11-01 → 03-15)    ███████████
- AI-pilot 3 wijken (04-01 → 09-30)            █████████
  △ G5: Pilotstart (04-01)
  △ G6: Pilot-evaluatie (10-15)

2027
- Preventief onderhoud cyclus 2 (03-01 → 10-31) ███████████████████████
- Winterdienst seizoen 27/28 (11-01 → 03-15)    ███████████
- AI-schaalvergroting (Q2 → Q4)                 █████████
  △ G7: Halfjaarraadpleging (06-30)

2028
- Preventief onderhoud cyclus 3 (03-01 → 10-31) ███████████████████████
- Winterdienst seizoen 28/29 (11-01 → 03-15)    ███████████
  △ G8: Midterm evaluatie (06-30)

2029
- Preventief onderhoud cyclus 4 (03-01 → 10-31) ███████████████████████
- Afronding & overdracht (11-01 → 12-15)       ███████
  △ G9: Eindreview KPI’s/SLA (11-30)
  △ G10: Opleverdossier compleet (12-15)

Benodigde input: