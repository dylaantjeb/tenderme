Aannames
- Contractvorm UAV 2012 voor werken; looptijd tot 31-12-2029.
- Toegang tot gemeentelijk GIS-portaal en API wordt door opdrachtgever tijdig beschikbaar gesteld en onderhouden.
- Meldingen en prioritering van storingen via afgesproken meldkanaal; classificatie calamiteit conform gezamenlijke SLA-definitie.
- Werkvensters en verkeersbesluiten worden door opdrachtgever tijdig verleend na aanlevering TMP.
- HVO100 en secundaire materialen zijn marktconform beschikbaar; bij marktverstoring treedt de escalatie- en substitutiematrix in werking.
- Garantieperiode 12 maanden per afgeronde activiteit.

Uitsluitingen
- Bodemsanering, asbest- of PFAS-sanering buiten reguliere kaders valt buiten scope; meerwerk na akkoord.
- Groot onderhoud dat ontwerpwijzigingen vereist (reconstructies) uitsluitend op opdrachtbasis via minicompetitie/optiewerk.
- Nutsverleggingen en schade aan kabels/leidingen die niet conform KLIC-informatie lagen: verrekend conform UAV 2012.

Financiële consequenties
- Wij hanteren vaste uurtarieven en eenheidsprijzen conform het prijsblad; indexering conform contractbepalingen.
- Wijzigingen in wet- en regelgeving (brandstofaccijns/EMVI-voorwaarden) worden als onvoorziene omstandigheden beschouwd en in goed overleg verrekend.
- Onwerkbaar weer: conform UAV 2012-regeling; inzet noodploeg voor calamiteiten valt binnen SLA, meerinzet in overleg.

Juridisch
- Gegevensverwerking conform AVG; DPIA-light en verwerkersovereenkomst van toepassing op GIS-gegevens.
- Eigendom data: blijft bij opdrachtgever; gebruiksrecht voor uitvoeringsdoeleinden.

Benodigde input: