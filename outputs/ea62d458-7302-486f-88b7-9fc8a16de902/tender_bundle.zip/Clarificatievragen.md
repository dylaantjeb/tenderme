# Clarificatievragen

| Nr | Vraag | Reden | Verwachte impact | Prioriteit |
|----|-------|-------|------------------|------------|
| 1 | Is er een specifieke softwarevoorkeur voor GIS-rapportages? | Om compatibiliteit te waarborgen | Efficiëntie in rapportage | Hoog |
| 2 | Zijn er specifieke eisen voor de communicatie met bewoners? | Om aan verwachtingen te voldoen | Stakeholdertevredenheid | Middel |

Benodigde input:
- Antwoorden op clarificatievragen