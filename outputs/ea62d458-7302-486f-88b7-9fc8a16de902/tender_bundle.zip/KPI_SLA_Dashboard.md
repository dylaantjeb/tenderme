# KPI/SLA Dashboard

| KPI/SLA | Target | Meetmethode | Frequentie | Escalatie | Verantwoordelijke |
|---------|--------|-------------|------------|-----------|-------------------|
| Klanttevredenheid | ≥ 8,0 | Enquêtes opdrachtgever | Halfjaarlijks | Escalatie naar directie | Kwaliteitsmanager |
| Responstijd storingen | ≤ 2 uur | Incidentregistratie | Continu | Escalatie naar projectleider | Operationeel Manager |
| Opleveringen binnen planning | ≥ 95% | Projectrapportages | Maandelijks | PMO-escalatie | Projectmanager |
| CO₂-reductie t.o.v. referentie | ≥ 15% | Brandstof/CO₂-monitor | Kwartaal | Duurzaamheidsmanager | Duurzaamheidsmanager |
| Ongevallen | 0 | VGM-rapportage | Continu | Veiligheidscoördinator | Veiligheidscoördinator |

Benodigde input:
- Geen aanvullende input vereist