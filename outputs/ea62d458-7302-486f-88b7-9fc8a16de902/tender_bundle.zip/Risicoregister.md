# Risicoregister

| Nr | Risico | Kans | Impact | Score | Maatregel | Eigenaar | Status |
|----|--------|------|--------|-------|-----------|----------|--------|
| 1 | Weersvertraging | Middel | Hoog | 9 | Buffers + alternatieve werktijden | Projectleider | Open |
| 2 | Personeelstekort | Laag | Hoog | 6 | Flexpool & vaste onderaannemers | HR Manager | Open |
| 3 | Materiaaltekort | Laag | Hoog | 6 | Vaste leverancierscontracten | Inkoop Manager | Open |
| 4 | Omgevingsklachten | Laag | Middel | 4 | Proactieve bewonerscommunicatie | Communicatie Manager | Open |

Benodigde input:
- Geen aanvullende input vereist