# Assumpties en Uitsluitingen

## Assumpties
| Aanname | Rationale | Impact bij afwijking |
|---------|-----------|----------------------|
| Prijsstelling is vast | Contractuele zekerheid | Heronderhandeling noodzakelijk |
| Toegang tot werkgebied | Vereist voor uitvoering | Vertraging in planning |

## Uitsluitingen
| Uitsluiting | Toelichting | Financiële consequentie |
|-------------|-------------|-------------------------|
| Weersomstandigheden | Geen aansprakelijkheid voor weersvertraging | N.v.t. |

Benodigde input:
- Geen aanvullende input vereist