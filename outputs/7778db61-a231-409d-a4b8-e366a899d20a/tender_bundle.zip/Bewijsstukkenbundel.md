Bewijstukkenbundel
Plan van Aanpak
- Samenvatting uitvoering, veiligheidsmiddelen, verkeersmaatregelen, kwaliteitsborging, en GIS-integratie.
- Bewijsstuk: Plan van Aanpak (gedigitaliseerd) + referenties naar relevante normen en methoden.

Risicodossier
- Lijst van geïdentificeerde risico’s, prioriteit, mitigaties en toewijzing verantwoordelijkheden.
- Bewijsstuk: Risicoregister met actuele status en KPI- koppelingen.

KPI-overzicht
- Overzicht van alle KPI’s, definities, meetpunten, brondata, frequentie en escalatiepaden.
- Bewijsstuk: KPI-overzicht met gekoppelde datastromen en rapportage-indicatoren.

Benodigde input:
