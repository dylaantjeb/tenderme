Assumpties en Uitsluitingen
Assumpties
- Pricing is locked en staat vast gedurende de afgesproken periodes.
- Operaties worden primair uitgevoerd binnen de gemeentelijke werktijden tenzij expliciet anders afgesproken.
- Afhankelijkheden op klantkant (toegang, GIS-data, vergunningen) zijn tijdig beschikbaar.
- 12 maanden garantie op uitgevoerde werken na oplevering.

Uitsluitingen
- Eventuele renovaties buiten het overeengekomen werkgebied vallen buiten de scope.
- Schades veroorzaakt door externe factoren zonder toedoen van de opdrachtnemer zijn uitgesloten.
- Updates aan bestaande GIS-architectuur die niet noodzakelijk zijn voor uitvoering.

Benodigde input:
