# Placeholder voor Inschrijvingsbiljet.xlsx

Dit is een gegenereerde placeholder. De daadwerkelijke template wordt downstream gemapt.

Benodigde input:
- (compleet)
