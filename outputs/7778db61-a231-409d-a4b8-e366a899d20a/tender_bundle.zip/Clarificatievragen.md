Clarificatievragen aan de opdrachtgever
1) Zijn er specifieke GIS-bronnen/formaten waarin de digitale oplevering moet plaatsvinden? (bv. WMS, WFS, GeoJSON)
2) Welke CO2-meetmethodiek moet exact toegepast worden voor de CO2-reductiebenchmark?
3) Is er een exacte calibratie of referentiewaarde voor CO2-reductie ten opzichte van een baselinemeting?
4) Welk detailniveau van de opleverdocumentatie is vereist bij oplevering (as-built, veldrapportages, foto’s, inspectierapporten)?
5) Graag bevestiging over de beschikbaarheid van 24/7 storingsdienst (jaargetuigingen en responstijden implementeren).

Benodigde input:
