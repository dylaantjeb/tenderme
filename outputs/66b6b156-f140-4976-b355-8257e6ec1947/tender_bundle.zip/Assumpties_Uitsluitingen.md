# Assumpties en Uitsluitingen

## Assumpties
| Aanname | Rationale | Impact bij afwijking |
|---------|-----------|----------------------|
| Prijzen zijn vastgezet | Marktfluctuaties worden vermeden | Heronderhandeling van contracten |

## Uitsluitingen
| Uitsluiting | Toelichting | Financiële consequentie |
|-------------|-------------|-------------------------|
| Onvoorziene weersomstandigheden | Niet opgenomen in planning | Extra kosten voor vertraging |

Benodigde input:
- Geen
