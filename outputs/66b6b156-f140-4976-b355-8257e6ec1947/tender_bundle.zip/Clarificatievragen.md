# Clarificatievragen

| Nr | Vraag | Reden | Verwachte impact | Prioriteit |
|----|-------|-------|------------------|------------|
| 1 | Is er een specifieke softwarevoorkeur voor GIS-integratie? | Bepalen van compatibiliteit | Mogelijke aanpassing in IT-infrastructuur | Hoog |

Benodigde input:
- Antwoorden van de opdrachtgever
