ASCII Gantt (weken 1-16)

Legenda: [====] actief, [..] buffer/afhankelijkheid

Wk:   1   2   3   4   5   6   7   8   9  10  11  12  13  14  15  16
Init.: [====]
Govern:     [==]
Analyse:     [====]
Ontwerp:         [====]
Config.:             [======]
Testen:                  [=====]
Migr.proef1:          [==]
Migr.proef2:                [==]
Training:                     [====]
Go/No-Go:                          [=]
Go-Live:                            [=]
Hypercare:                             [====]
Beheer (doorlopend):                                 [>>>>>>>>]

Mijlpalen
- M1 Kick-off (wk1)
- M2 As-is/To-be afgerond (wk4)
- M3 Ontwerp goedgekeurd (wk6)
- M4 Proefmigraties afgerond (wk10)
- M5 Acceptatietest OK (wk11)
- M6 Go-live (wk12)
- M7 Hypercare afgerond (wk16)

Benodigde input:
- Voorkeurs-onderhoudsvensters en black-out data.
- Externe afhankelijkheden (leveranciers, certificaten, domeinen).
- Beschikbaarheid kerngebruikers voor test en training. 
>>>