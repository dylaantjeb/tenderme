# KPI/SLA Dashboard

| KPI/SLA | Target | Meetmethode | Frequentie | Escalatie | Verantwoordelijke |
|---------|--------|-------------|------------|-----------|-------------------|
| Klanttevredenheid | ≥ 8,0 | Enquête opdrachtgever | Maandelijks | Escalatie naar directie | Accountmanager |
| Responstijd storingen | ≤ 2 uur | Storingslogboek | Dagelijks | Escalatie naar projectleider | Technisch Manager |
| Opleveringen binnen planning | ≥ 95% | Projectoverzicht | Maandelijks | Escalatie naar PMO | Projectmanager |
| CO₂-reductie t.o.v. referentie | ≥ 15% | Brandstofmonitor | Kwartaal | Escalatie naar duurzaamheidsmanager | Duurzaamheidsmanager |
| Ongevallen | 0 | VGM-rapportage | Maandelijks | Escalatie naar veiligheidscoördinator | Veiligheidscoördinator |

Benodigde input:
- Geen