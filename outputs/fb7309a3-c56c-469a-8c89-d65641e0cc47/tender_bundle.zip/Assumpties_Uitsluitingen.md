# Assumpties en Uitsluitingen

## Assumpties
| Aanname | Rationale | Impact bij afwijking |
|---------|-----------|----------------------|
| Prijsstelling is vast | Contractuele zekerheid | Heronderhandeling van tarieven |

## Uitsluitingen
| Uitsluiting | Toelichting | Financiële consequentie |
|-------------|-------------|-------------------------|
| Onvoorziene weersomstandigheden | Niet beïnvloedbaar | Mogelijke vertragingen |

Benodigde input:
- Geen