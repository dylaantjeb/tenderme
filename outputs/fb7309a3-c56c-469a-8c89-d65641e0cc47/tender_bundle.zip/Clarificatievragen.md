# Clarificatievragen

| Nr | Vraag | Reden | Verwachte impact | Prioriteit |
|----|-------|-------|------------------|------------|
| 1 | Wat zijn de specifieke duurzaamheidsdoelstellingen van de gemeente? | Onvoldoende duidelijkheid | Aanpassing van aanpak | Hoog |

Benodigde input:
- Antwoorden van de aanbestedende dienst