# Risicoregister

| Nr | Risico | Kans | Impact | Score | Maatregel | Eigenaar | Status |
|----|--------|------|--------|-------|-----------|----------|--------|
| 1 | Weersvertraging | Middel | Middel | 6 | Buffer in planning, alternatieve werktijden | Projectleider | Open |
| 2 | Personeelstekort | Laag | Hoog | 8 | Samenwerking met vaste onderaannemers | HR Manager | Open |
| 3 | Materiaaltekort | Laag | Hoog | 8 | Vaste leverancierscontracten | Inkoop Manager | Open |
| 4 | Omgevingsklachten | Laag | Middel | 4 | Proactieve communicatie met bewoners | Communicatie Manager | Open |

Benodigde input:
- Geen