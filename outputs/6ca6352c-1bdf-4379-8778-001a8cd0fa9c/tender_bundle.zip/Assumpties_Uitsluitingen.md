Assumpties en Uitsluitingen — UTR-MAINT-2025-041

Assumpties
- Werkvensters: nacht/daluren toegestaan waar aangetoond hinderreductie oplevert.
- Toegang GIS en SHARE-API wordt door opdrachtgever verstrekt met benodigde rechten binnen 10 werkdagen na gunning.
- Zout/pekelvoorraad wordt conform gemeentelijke afspraken beschikbaar gesteld of apart verrekend.
- Vergunningen voor verkeersmaatregelen worden tijdig verleend bij volledige aanvraag door ons (min. 10 werkdagen).

Uitsluitingen
- Schade door derden buiten onze werkzaamheden valt buiten scope, wel signaleren en veiligstellen.
- Bodemsanering bij verontreiniging buiten normale onderhoudswerkzaamheden valt buiten vaste prijzen.
- Grote reconstructies of verleggingen van kabels/leidingen maken geen deel uit van dit raamcontract.

Benodigde input:
- Bevestiging leveringsgrenzen winterdiensten (zout/pekel).
- Escalatiecontact bij urgente verkeersmaatregelen.>>>