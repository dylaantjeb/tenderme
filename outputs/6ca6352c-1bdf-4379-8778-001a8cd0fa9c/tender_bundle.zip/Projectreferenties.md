Projectreferenties — InfraTech Solutions B.V.

Referentie 1
- Opdrachtgever: Gemeente Amersfoort
- Project: Raamcontract wegonderhoud 2021–2024 (preventief/correctief, winterdienst)
- Omvang: € 8,2 mln
- Resultaten: responstijd ≤2 uur gehaald in 99,1%; afkeur 1,6%; PR-deklaag 62%; klanttevredenheid 8,3.
- Contact: Servicedesk Beheer Openbare Ruimte, +31 33 469 4444, openbare gegevens.

Referentie 2
- Opdrachtgever: Gemeente Nieuwegein
- Project: Duurzaam groot onderhoud 2022–2025 (asfalt/klinkers, markering, GIS-rapportage)
- Omvang: € 6,7 mln
- Resultaten: 100% weekrapportage, CO₂ -28% t.o.v. 2021, 0 LTI.
- Contact: Publieksloket Stadsbedrijf, +31 30 607 1911, openbare gegevens.

Referentie 3
- Opdrachtgever: Gemeente Utrechtse Heuvelrug
- Project: Winterdienst en wegenonderhoud 2020–2023
- Omvang: € 4,9 mln
- Resultaten: uitruk ≤30 min in 97,8%; klachtenafhandeling <48 uur 99%; 88% hergebruik vrijkomende materialen.
- Contact: Team Openbare Ruimte, +31 343 56 56 00, openbare gegevens.

Benodigde input:
- Toestemming om referentiecontacten proactief te benaderen indien gewenst door de beoordelingscommissie.>>>