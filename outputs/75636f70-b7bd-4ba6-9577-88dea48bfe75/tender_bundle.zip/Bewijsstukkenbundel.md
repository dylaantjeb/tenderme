Bijlage | Beschrijving | Relatie (W-xx/KO/REQ) | Status | Verwijzing (pag./sectie)
B-01 | ISO 9001/14001 certificaten (scope GWW) | KO; W-09 | Definitief | Cert.-set p.1–6
B-02 | EPD’s asfaltmengsels en RAP-bewijs | W-07; REQ | Definitief | EPD-map sectie 2
B-03 | Projectkwaliteitsplan + ITP’s (incl. storings-SLA) | W-01; W-09; REQ | Definitief | PQP §3–7
B-04 | Veiligheidsplan (VTWS) CROW 96a/96b | W-04; REQ | Definitief | VTWS §2–5
B-05 | Inspectieprotocol CROW 146/147 + formats | W-02 | Definitief | Inspectiehandboek §1–4
B-06 | GIS-API specificatie en datamodel | W-05; REQ | Definitief | GIS techdoc §2
B-07 | Emissiearm materieelplan + vlootlijst ZE/HVO | W-03; REQ | Definitief | Materieelboek §1–3
B-08 | Markering meetprotocol (RA) + kalibratiecertificaten | W-06 | Definitief | Markering §3
B-09 | VGM-auditprotocol + formulieren | W-04 | Definitief | VGM §4–6
B-10 | AI-planning en voorspelmodel (methode & validatie) | W-02; W-12 | Concept | AI whitepaper §5
B-11 | Omgevingsmanagementplan + communicatieformats | W-08 | Definitief | Omg.plan §2–4
B-12 | 24/7 meldkamerproces en paraatheidsschema | W-01 | Definitief | SLA §1–2
B-13 | Voorbeeld weekrapportage (GIS-screenshots) | W-05 | Definitief | Bijlage fig. 1–5
B-14 | Klinkerhergebruik-methodiek en traceerbaarheid | W-07 | Definitief | Circulariteit §3
B-15 | Winterdienst draaiboek + routes en sensoren | W-10 | Definitief | Winter §2–5
B-16 | Social Return plan en partners | W-11 | Definitief | SR §1–3
B-17 | Digitale twin pilotplan (roadmap 2026) | W-12 | Concept | Twin §1–2
B-18 | UAV 2012 akkoordverklaring | REQ | Definitief | Juridisch §1
B-19 | Data Protection Agreement (AVG) voor GIS | REQ | Concept | DPA §1–4
B-20 | GIBIT/ARVODI verklaring “niet van toepassing werken” | REQ | Definitief | Juridisch §2

Benodigde input: