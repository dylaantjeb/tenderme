NvI-vragen en impact

1) Vraag: Bevestigt u dat UAV 2012 en RAW van toepassing zijn en dat GIBIT/ARVODI niet gelden voor deze raamovereenkomst werken?
- Impact: Contract duidelijkheid; risico op tegenstrijdige bepalingen wordt verlaagd.
- Prioriteit: Hoog.

2) Vraag: Welke GIS-API-versie en verplichte datavelden hanteert de gemeente (schema, validatieregels, fotometadata)?
- Impact: KPI-04 (100% binnen 48 uur) en foutloze data-inname.
- Prioriteit: Hoog.

3) Vraag: Mag in de binnenstad standaard nachtwerk worden toegepast voor hinderbeperking, mits geluidsarme maatregelen worden gevolgd?
- Impact: KPI-12 (tevredenheid) en planning.
- Prioriteit: Middel.

4) Vraag: Wil de gemeente laadpunten op strategische gemeentewerf-locaties beschikbaar stellen voor ZE-materieel?
- Impact: KPI-05/06 (ZE-uren en CO₂).
- Prioriteit: Middel.

5) Vraag: Wat is de definitie “spoedmelding” voor storingen (categorieën A/B/C) en gewenst herstelvenster per categorie?
- Impact: KPI-01/02 SLA-invulling.
- Prioriteit: Hoog.

6) Vraag: Zijn er minimumeisen voor RAP-percentage per mengsel/wegtype of geldt het gemiddelde per jaar?
- Impact: KPI-07 en receptkeuze.
- Prioriteit: Middel.

7) Vraag: Kan de gemeente referentiewaarden voor markering RA delen per wegcategorie (EA/EB), inclusief wintercorrecties?
- Impact: KPI-10 conformiteit en hersteltermijn.
- Prioriteit: Laag.

8) Vraag: Kan Social Return worden ingevuld via ketenpartners en onderwijsinstellingen, en mogen opleidingsuren meetellen?
- Impact: KPI-14 haalbaarheid.
- Prioriteit: Middel.

9) Vraag: Levert de gemeente een jaarlijkse evenementen- en werkembargo-kalender?
- Impact: Risico R7 planningconflicten.
- Prioriteit: Hoog.

10) Vraag: Is een digitale handtekening via TenderNed voldoende voor de UEA en overige formulieren?
- Impact: Compliance en inleverset compleet.
- Prioriteit: Hoog.

Benodigde input: