Planning (ASCII-Gantt) 2025–2029

Legenda: |====| taak, [G] gate review, (M) mijlpaal

2025
Q1   Q2   Q3   Q4
R0 Kick-off & Baseline        |====| 
Inspecties & Jaarplan 2025    |========| 
GIS-koppeling & Staging       |====|[G] 
Uitvoering clusters 2025           |======================| (M) Opl.2025
Winterdienst 2025-2026             |==========|

2026
Q1   Q2   Q3   Q4
Inspecties & Jaarplan 2026    |========| 
AI-voorspelmodel (v1)         |======[G]|==| 
Digitale twin pilot voorbere.      |====| 
Uitvoering clusters 2026           |======================| (M) Opl.2026
Winterdienst 2026-2027             |==========|

2027
Q1   Q2   Q3   Q4
Inspecties & Jaarplan 2027    |========| 
ZE-schaal-up & laadinfra       |====| 
Digitale twin pilot uitvoering      |==========|[G](M) Pilot live
Uitvoering clusters 2027           |======================| (M) Opl.2027
Winterdienst 2027-2028             |==========|

2028
Q1   Q2   Q3   Q4
Inspecties & Jaarplan 2028    |========| 
Optimalisatie circulariteit        |======| 
Uitvoering clusters 2028           |======================| (M) Opl.2028
Winterdienst 2028-2029             |==========|

2029
Q1   Q2   Q3   Q4
Inspecties & Jaarplan 2029    |========| 
Eind-CO₂-reductie traject         |======|[G] 
Uitvoering clusters 2029           |======================| 
Eindoplevering & Evaluatie               |====| (M) Eindoplevering

Gate reviews: 
- R0 Kick-off 01-2025
- G: GIS-acceptatie 04-2025
- G: AI v1-go/no go 06-2026
- G: Pilot twin live 10-2027
- G: CO₂-resultaatcheck 06-2029

Benodigde input: